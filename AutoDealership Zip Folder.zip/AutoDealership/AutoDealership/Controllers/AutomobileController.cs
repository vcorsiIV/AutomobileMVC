﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoDealership.Models;

/// <summary>
/// The Automobile Controller:
/// From here the Views for the Index, Create,
/// Details, and Edit will be created, as well
/// as the List of the given data that will be
/// used.
/// </summary>

namespace AutoDealership.Controllers
{
    public class AutomobileController : Controller
    {
        // GET: Automobile
        public ActionResult Index()
        {
            var automobiles = from a in amList
                              orderby a.ID
                              select a;

            return View(automobiles);
        }

        public ActionResult Details(int id)
        {
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Automobile am)
        {
            try
            {
                amList.Add(am);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Edit(int id)
        {
            List<Automobile> amList = GetAutomobileList();
            var automobile = amList.Single(m => m.ID == id);
            return View(automobile);
        }

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                var automobile = amList.Single(m => m.ID == id);
                if (TryUpdateModel(automobile))
                {
                    return RedirectToAction("Index");
                }
                return View();
            }
            catch
            {
                return View();
            }
        }

        [NonAction]
        public List<Automobile> GetAutomobileList()
        {
            return new List<Automobile>
            {
                new Automobile
                {
                    ID = 1,
                    Make = "Ford",
                    Model = "Mustang",
                    Year = 2004,
                    Color = "Red"
                },

                new Automobile
                {
                    ID = 2,
                    Make = "Lexus",
                    Model = "NX 300",
                    Year = 2014,
                    Color = "White"
                },

                new Automobile
                {
                    ID = 3,
                    Make = "Lincoln",
                    Model = "MKC",
                    Year = 2000,
                    Color = "Slate Gray"
                },

                new Automobile
                {
                    ID = 4,
                    Make = "BMW",
                    Model = "M6",
                    Year = 2007,
                    Color = "Teal"
                },

                new Automobile
                {
                    ID = 5,
                    Make = "Chevrolet",
                    Model = "Corvette",
                    Year = 1998,
                    Color = "Forest Green"
                },

                new Automobile
                {
                    ID = 6,
                    Make = "FIAT",
                    Model = "500",
                    Year = 2015,
                    Color = "Vibrant Blue"
                },

                new Automobile
                {
                    ID = 7,
                    Make = "Jaguar",
                    Model = "XF",
                    Year = 2002,
                    Color = "Mustard Yellow"
                },

                new Automobile
                {
                    ID = 8,
                    Make = "Ford",
                    Model = "Ranger",
                    Year = 1999,
                    Color = "Gold"
                },

                new Automobile
                {
                    ID = 9,
                    Make = "Jeep",
                    Model = "Cherokee",
                    Year = 2006,
                    Color = "Red"
                },

                new Automobile
                {
                    ID = 10,
                    Make = "Toyota",
                    Model = "Highlander",
                    Year = 2010,
                    Color = "Silver"
                }
            };
        }

        public static List<Automobile> amList = new List<Automobile>
        {
            new Automobile
            {
                    ID = 1,
                    Make = "Ford",
                    Model = "Mustang",
                    Year = 2004,
                    Color = "Red"
            },

            new Automobile
            {
                ID = 2,
                Make = "Lexus",
                Model = "NX 300",
                Year = 2014,
                Color = "White"
            },
            new Automobile
            {
                ID = 3,
                Make = "Lincoln",
                Model = "MKC",
                Year = 2000,
                Color = "Slate Gray"
            },
            new Automobile
            {
                ID = 4,
                Make = "BMW",
                Model = "M6",
                Year = 2007,
                Color = "Teal"
            },
            new Automobile
            {
                ID = 5,
                Make = "Chevrolet",
                Model = "Corvette",
                Year = 1998,
                Color = "Forest Green"
            },
            new Automobile
            {
                ID = 6,
                Make = "FIAT",
                Model = "500",
                Year = 2015,
                Color = "Vibrant Blue"
            },
            new Automobile
            {
                ID = 7,
                Make = "Jaguar",
                Model = "XF",
                Year = 2002,
                Color = "Mustard Yellow"
            },
            new Automobile
            {
                ID = 8,
                Make = "Ford",
                Model = "Ranger",
                Year = 1999,
                Color = "Gold"
            },
            new Automobile
            {
                ID = 9,
                Make = "Jeep",
                Model = "Cherokee",
                Year = 2006,
                Color = "Red"
            },
            new Automobile
            {
                ID = 10,
                Make = "Toyota",
                Model = "Highlander",
                Year = 2010,
                Color = "Silver"
            }
        };
    }
}