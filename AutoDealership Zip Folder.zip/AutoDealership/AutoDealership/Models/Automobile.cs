﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoDealership.Models;
/// <summary>
/// The Automobile Model Class:
/// Within this class is the fields that this
/// MVC will use.
/// </summary>

namespace AutoDealership.Models
{
    public class Automobile
    {
        public int ID { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public string Color { get; set; }
    }
}